-- jane petrovna
-- v 0.0
-- handle system initialization

kernel.kprint("kernel init file executed", "OK", kernel.colors.green)